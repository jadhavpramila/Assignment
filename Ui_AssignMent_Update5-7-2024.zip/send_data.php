<?php 


require_once("config.php");
if((isset($_POST['your_name'])&& $_POST['your_name'] !='') && (isset($_POST['your_email'])&& $_POST['your_email'] !='') && (isset($_POST['your_phone'])&& $_POST['your_phone'] !=''))
{
 $yourName = $_POST['your_name'];
$yourEmail = $_POST['your_email'];
$yourInterest = $_POST['your_interest'];
$yourPhone = $_POST['your_phone'];
$yourMessage = $_POST['your_message'];




$sql="INSERT INTO contact_data (contact_name, contact_email, contact_phone, contact_interest, contact_message) VALUES ('".$yourName."','".$yourEmail."', '".$yourPhone."', '".$yourInterest."', '".$yourMessage."')";

if(!$result = $conn->query($sql)){
die('There was an error running the query [' . $conn->error . ']');
}
else
{
echo "Thank you! We will contact you soon";
}
}
else
{
echo "Please fill mandatory fields";
}
?>