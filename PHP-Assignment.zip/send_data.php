<?php 

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
require_once  'vendor/autoload.php';



require_once("config.php");
if((isset($_POST['your_name'])&& $_POST['your_name'] !='') && (isset($_POST['your_email'])&& $_POST['your_email'] !=''))
{
 require_once("index.php");
 $yourName = $_POST['your_name'];
$yourEmail = $_POST['your_email'];
$yourPhone = $_POST['your_phone'];

$mail = new PHPMailer();
       $mail->isSMTP();
       $mail->Host = 'live.smtp.mailtrap.io';
       $mail->SMTPAuth = true;
       $mail->Username = 'api';
       $mail->Password = '********f254';
       $mail->SMTPSecure = 'ssl';
       $mail->Port = 465;
       $mail->setFrom($yourEmail, 'Pramila Jadhav');
       $mail->addAddress('jadhav.pramilasantosh@gmail.com', 'Me');
       $mail->Subject = 'New message from your website';

       // Enable HTML if needed
       $mail->isHTML(true);
       $bodyParagraphs = ["Name: {$yourName}", "Email: {$yourEmail}"];
       $body = join('<br />', $bodyParagraphs);
       $mail->Body = $body;
      // echo $body;

       if (!$mail->send()) {
        echo 'Email not sent. An error was encountered: ' . $mail->ErrorInfo . "\n";
    } else {
        echo 'Message has been sent to ';
    }


     

$sql="INSERT INTO contact_data (contact_name, contact_email, contact_phone) VALUES ('".$yourName."','".$yourEmail."', '".$yourPhone."')";
$result = mysqli_query($conn, $sql);


if(!$result){
echo ('There was an error running the query [' . $result . ']');
}
else
{
echo "Thank you! We will contact you soon";
}
}
else
{
echo "Please fill Name and Email";
}
?>