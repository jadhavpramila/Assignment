<!DOCTYPE html>
<html lang="zxx">
  <head>
    <title>Real Estate | Home</title>
    <!--meta tags -->
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <!--booststrap-->
    <link
      href="css/bootstrap.min.css"
      rel="stylesheet"
      type="text/css"
      media="all"
    />
    <!--//booststrap end-->
    <link href="css/font-awesome.min.css" rel="stylesheet" />
    <!-- //font-awesome icons -->
    <!--stylesheets-->
    <link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
    <!--//stylesheets-->
    <link
      href="//fonts.googleapis.com/css?family=Open+Sans:400,600,700"
      rel="stylesheet"
    />
    <link
      href="//fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600"
      rel="stylesheet"
    />
  </head>
  <body>
    <div class="main-top" id="home">
      <!-- header -->
      <div class="headder-top">
        <div class="container-fluid">
          <!-- nav -->
          <nav>
            <div id="logo">
              <h1><a class="" href="index.html">Realty</a></h1>
            </div>
            <label for="drop" class="toggle">Menu</label>
            <input type="checkbox" id="drop" />
            <ul class="menu mt-2">
              <li class="active"><a href="index.html">Home</a></li>
              <li class="mx-lg-3 mx-md-2 my-md-0 my-1">
                <a href="#about">About</a>
              </li>
              <li><a href="#gallery">Gallery</a></li>
              <li><a href="#contact">Contact Us</a></li>
            </ul>
          </nav>
          <!-- //nav -->
        </div>
      </div>
      <!-- //header -->
      <!-- banner -->
      <div class="slider-img one-img text-center">
        <div class="container">
          <div class="slider-info">
            <h5>Use our site to find your home</h5>
            <div class="slider-banner">
              <h4>Find The Perfect Home</h4>
            </div>
            <div class="read-more-btn">
              <a href="#contact">Contact</a>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- //banner -->
    <div class="clearfix"></div>
    <!-- //banner -->
    <!--About -->
    <section class="about py-lg-4 py-md-3 py-sm-3 py-3" id="about">
      <div class="container py-lg-5 py-md-5 py-sm-4 py-3">
        <div class="row">
          <div class="col-lg-6 col-md-6 col-12">
            <div class="about-img"></div>
          </div>
          <div class="col-lg-6 col-md-6 col-12">
            <h3 class="title mt-lg-0 mt-md-0 mt-sm-4 mt-3 mb-2">About Us</h3>
            <div class="hr-line mb-md-4 mb-sm-3 mb-3"></div>
            <div class="about-text">
              <p>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                eiusmod tempor incididunt ut labore et Lorem ipsum dolor sit
                amet, consectetur adipiscing elit, sed do eiusmod tempor
                incididunt ut labore et Lorem ipsum dolor sit amet, consectetur
                adipiscing elit, sed do eiusmod tempor incididunt ut labore et
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                eiusmod tempor incididunt
              </p>
            </div>
            <div class="">
              <div class="about-more-contact">
                <a href="#contact" class="scroll">Contact us</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!--//About-->
    <!-- gallery -->
    <section class="gallery py-lg-4 py-md-3 py-sm-3 py-3" id="gallery">
      <div class="container-fluid py-lg-5 py-md-5 py-sm-4 py-3">
        <div class="title-sub text-center mb-lg-5 mb-md-4 mb-sm-4 mb-3">
          <h3 class="title mb-2">Our Gallery</h3>
          <div class="hr-line text-center mb-md-4 mb-sm-3 mb-3"></div>
          <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
            eiusmod <br />tempor incididunt ut labore et
          </p>
        </div>
        <div class="row mx-0">
          <div class="col-lg-3 col-md-3 col-sm-6 p-0">
            <div>
              <a href="#gal7" class="gallery-grids"
                ><img
                  src="images/gallery3.jpg"
                  alt="gallery image"
                  class="img-fluid"
                />
                <div class="img-overlay">
                  <img src="./images/zoom-in-white.png" alt="zoomin" />
                </div>
              </a>
            </div>
          </div>
          <div class="col-lg-3 col-md-3 col-sm-6 p-0">
            <div>
              <a href="#gal8" class="gallery-grids"
                ><img
                  src="images/gallery4.jpg"
                  alt="gallery image"
                  class="img-fluid" />
                <div class="img-overlay">
                  <img src="./images/zoom-in-white.png" alt="zoomin" /></div
              ></a>
            </div>
          </div>
          <div class="col-lg-3 col-md-3 col-sm-6 p-0">
            <div>
              <a href="#gal1" class="gallery-grids"
                ><img
                  src="images/gallery1.jpg"
                  alt="gallery image"
                  class="img-fluid" />
                <div class="img-overlay">
                  <img src="./images/zoom-in-white.png" alt="zoomin" /></div
              ></a>
            </div>
          </div>
          <div class="col-lg-3 col-md-3 col-sm-6 p-0">
            <div>
              <a href="#gal2" class="gallery-grids"
                ><img
                  src="images/gallery2.jpg"
                  alt="gallery image"
                  class="img-fluid" />
                <div class="img-overlay">
                  <img src="./images/zoom-in-white.png" alt="zoomin" /></div
              ></a>
            </div>
          </div>
          <div class="col-lg-3 col-md-3 col-sm-6 p-0">
            <div>
              <a href="#gal3" class="gallery-grids"
                ><img
                  src="images/gallery1.jpg"
                  alt="gallery image"
                  class="img-fluid" />
                <div class="img-overlay">
                  <img src="./images/zoom-in-white.png" alt="zoomin" /></div
              ></a>
            </div>
          </div>
          <div class="col-lg-3 col-md-3 col-sm-6 p-0">
            <div>
              <a href="#gal4" class="gallery-grids"
                ><img
                  src="images/gallery2.jpg"
                  alt="gallery image"
                  class="img-fluid" />
                <div class="img-overlay">
                  <img src="./images/zoom-in-white.png" alt="zoomin" /></div
              ></a>
            </div>
          </div>
          <div class="col-lg-3 col-md-3 col-sm-6 p-0">
            <div>
              <a href="#gal5" class="gallery-grids"
                ><img
                  src="images/gallery3.jpg"
                  alt="gallery image"
                  class="img-fluid" />
                <div class="img-overlay">
                  <img src="./images/zoom-in-white.png" alt="zoomin" /></div
              ></a>
            </div>
          </div>
          <div class="col-lg-3 col-md-3 col-sm-6 p-0">
            <div>
              <a href="#gal6" class="gallery-grids p-0"
                ><img
                  src="images/gallery4.jpg"
                  alt="gallery image"
                  class="img-fluid" />
                <div class="img-overlay">
                  <img src="./images/zoom-in-white.png" alt="zoomin" /></div
              ></a>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!--// gallery-main -->
    <!-- popup-->
    <div id="gal7" class="popup-effect">
      <div class="popup">
        <img src="images/gallery3.jpg" alt="Popup Image" class="img-fluid" />
        <a class="close" href="#gallery">&times;</a>
      </div>
    </div>
    <!-- //popup -->
    <!-- popup-->
    <div id="gal8" class="popup-effect">
      <div class="popup">
        <img src="images/gallery4.jpg" alt="Popup Image" class="img-fluid" />
        <a class="close" href="#gallery">&times;</a>
      </div>
    </div>
    <!-- //popup -->
    <!-- popup-->
    <div id="gal1" class="popup-effect">
      <div class="popup">
        <img src="images/gallery1.jpg" alt="Popup Image" class="img-fluid" />
        <a class="close" href="#gallery">&times;</a>
      </div>
    </div>
    <!-- //popup -->
    <!-- popup-->
    <div id="gal2" class="popup-effect">
      <div class="popup">
        <img src="images/gallery2.jpg" alt="Popup Image" class="img-fluid" />
        <a class="close" href="#gallery">&times;</a>
      </div>
    </div>
    <!-- //popup -->
    <!-- popup-->
    <div id="gal3" class="popup-effect">
      <div class="popup">
        <img src="images/gallery1.jpg" alt="Popup Image" class="img-fluid" />
        <a class="close" href="#gallery">&times;</a>
      </div>
    </div>
    <!-- //popup -->
    <!-- popup-->
    <div id="gal4" class="popup-effect">
      <div class="popup">
        <img src="images/gallery2.jpg" alt="Popup Image" class="img-fluid" />
        <a class="close" href="#gallery">&times;</a>
      </div>
    </div>
    <!-- //popup -->
    <!-- popup-->
    <div id="gal5" class="popup-effect">
      <div class="popup">
        <img src="images/gallery3.jpg" alt="Popup Image" class="img-fluid" />
        <a class="close" href="#gallery">&times;</a>
      </div>
    </div>
    <!-- //popup -->
    <!-- popup-->
    <div id="gal6" class="popup-effect">
      <div class="popup">
        <img src="images/gallery4.jpg" alt="Popup Image" class="img-fluid" />
        <a class="close" href="#gallery">&times;</a>
      </div>
    </div>
    <!-- //popup -->
    <!--//gallery -->
    <!--Footer-->
    <footer class="py-lg-4 py-md-3 py-sm-3 py-3" id="contact">
      <div class="container py-lg-5 py-md-5 py-sm-4 py-3">
        <div class="row">
          <div class="col-lg-5 footer-left-grid">
            <div class="mb-lg-4 mb-3 footer-head">
              <h2><a href="index.html">Realty</a></h2>
            </div>
            <p class="">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
              eiusmod tempor incididunt ut labore etLorem ipsum dolor sit amet,
              consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
              labore et
            </p>
            <div class="mb-3 pt-lg-4 pt-3 footer-address">
              <h4>Get In Touch</h4>
            </div>
            <div class="footer_grid_left">
              <ul>
                <li>
                  <span class="fa fa-map" aria-hidden="true"> </span>
                  <p>Park Street, Pune</p>
                </li>
                <li>
                  <span class="fa fa-envelope-o" aria-hidden="true"> </span>
                  <p><a href="mailto:info@example.com">info@abcde.com</a></p>
                </li>
                <li>
                  <span class="fa fa-fax" aria-hidden="true"></span>
                  <p>(022)125368</p>
                </li>
                <li>
                  <span class="fa fa-phone" aria-hidden="true"> </span>
                  <p>+(91) 1122334455</p>
                </li>
              </ul>
            </div>
          </div>
          <div class="col-lg-7 contact-form pb-lg-3 pb-2">
            <form action="" method="post" id="contact-form">
              >
              <div class="row">
                <div
                  class="col-lg-12 col-md-12 col-sm-12 form-group contact-forms"
                >
                  <input
                    type="text"
                    class="form-control"
                    placeholder="Your Name"
                    name="your_name"
                    required=""
                  />
                </div>
              </div>
              <div class="row">
                <div
                  class="col-lg-6 col-md-6 col-sm-6 form-group contact-forms"
                >
                  <input
                    type="email"
                    class="form-control"
                    placeholder="Email"
                    name="your_email"
                    required=""
                  />
                </div>
                <div
                  class="col-lg-6 col-md-6 col-sm-6 form-group contact-forms"
                >
                  <input
                    type="text"
                    class="form-control"
                    placeholder="Phone"
                    name="your_phone"
                    required=""
                  />
                </div>
              </div>

              <div class="">
                <button type="submit" id="submit_btn" class="btn sent-butnn btn-lg">
                  Submit
                </button>
              </div>
            </form>
            <div class="response_msg"></div>
          </div>
        </div>
      </div>
    </footer>

   
    <!--//Footer-->
  </body>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
<script>
$(document).ready(function(){
$("#contact-form").on("submit",function(e){
e.preventDefault();
if($("#contact-form [name='your_name']").val() === '')
{
$("#contact-form [name='your_name']").css("border","1px solid red");
}
else if ($("#contact-form [name='your_email']").val() === '')
{
$("#contact-form [name='your_email']").css("border","1px solid red");
}
else
{

var sendData = $( this ).serialize();
$.ajax({
type: "POST",
url: "send_data.php",
data: sendData,
success: function(){
$(".response_msg").text("Thank you! We will contact you soon");
$(".response_msg").slideDown().fadeOut(3000);
$("#contact-form").find("input[type=text], input[type=email]").val("");
}
});
}
});
});
</script>
</html>
